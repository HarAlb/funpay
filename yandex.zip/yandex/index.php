<?php
	$lang = isset($_COOKIE["lang"]) ? $_COOKIE["lang"] : "en";
	$dir = basename(dirname(__FILE__));
	$current_path = ((isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] === "on") ? "https" : "http" ) . "://{$_SERVER['HTTP_HOST']}/{$dir}";
	$translate =  [
		"en" => [
			"global_title" => "Send Money Yandex",
			"language" => "language",
			"from" => "from",
			"mine" => "my wallet",
			"wallet" => "wallet",
			"price" => "price",
			"reset" => "reset",
			"pay" => "pay",
			"error_from" => "please use your wallet",
			"error_del" => "please don't delete required fields",
			"error_wallet" => "whis field must be number",
			"password" => "password",
			"expense" => "expensed",
			"transfer" => "transfer to account",
			"message" => "message please",
			"error_message" => "message can't be empty"
		],

		"ru" => [
			"global_title" => "Перевод денег",
			"language" => "язык",
			"from" => "откуда",
			"mine" => "мой кошелек",
			"wallet" => "кошелек",
			"price" => "сумма",
			"reset" => "сброс",
			"pay" => "заплатить",
			"error_from" => "пожалуйста, используйте свой кошелек",
			"error_del" => "пожалуйста, не удаляйте обязательные поля",
			"error_wallet" => "это поле должно быть числом",
			"password" => "пароль",
			"expense" => "спишется",
			"transfer" => "перевод на счет",
			"message" => "сообщение пожалуйста",
			"error_message" => "сообщение не может быть пустым"
		]
	];
	if( isset( $_POST["pay"] ) ){
		$errors = [];

		if( isset( $_POST["from"] ) ){

			if( ! ( trim( $_POST["from"] ) === $translate[$lang]["mine"] ) ){
				$errors["from"] = $translate[$lang]["error_form"]; 
			}

		}else{
			$errors["from"] = $translate[$lang]["error_del"];
		}

		if( isset( $_POST["wallet"] ) ){

			if( !is_numeric( $_POST["wallet"] ) ){
				$errors["wallet"] = $translate[$lang]["error_wallet"]; 
			}

		}else{
			$errors["wallet"] = $translate[$lang]["error_del"];
		}

		if( isset( $_POST["price"] ) ){
			
			if( !is_numeric( $_POST["price"] ) ){

				$errors["price"] = $translate[$lang]["error_wallet"]; 

			}

		}else{

			$errors["price"] = $translate[$lang]["error_del"];
		
		}

		if(empty( $errors )){
			$password = "<li><span>{$translate[$lang]['password']} : " . floor( rand(1000 , 9999)) . "</span></li>";
			$commision = intval( $_POST["price"] ) + (intval( $_POST["price"] )*0.5); 
			$wallet = "<li><span>{$translate[$lang]["expense"]} {$commision}р.</span></li>";
			$transfer = "<li><span>{$translate[$lang]["transfer"]} {$_POST["wallet"]}</span></li>";
			$res = "<ul>$password $wallet $transfer</ul>";
		}

	}

	if( isset( $_POST["translate"]) ){
		$error = [];
		if(!empty( $_POST["message"] )){

			if(preg_match('@Пароль[\r\n\t\s\0]*\:[\r\n\t\s\0]*([0-9]*)@isu', $_POST["message"] , $matches)){
				$password = $matches[1];
			}else{
				$password = "havn't";
			}

			if(preg_match('@Спишется[\r\n\t\s\0]*([0-9\,\.]*)@isu', $_POST["message"] , $matches)){
				$price = $matches[1];
			}else{
				$price = "havn't";
			}

			if(preg_match('@счет[\r\n\t\s\0]*(?:([0-9]*)|$)@isu', $_POST["message"] , $matches)){
				$wallet = $matches[1];
			}else{
				$wallet = "havn't";
			}

			$message_result = "$password password , $price price , $wallet wallet";
		}else{
			$error["message"] = $translate[$lang]["error_message"];
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Transfer Money</title>
	<style>
		
		ul:not(.languages),li{
			list-style-type: none;
			padding: 0;
		}

		.dflex{
			display: flex;
		}

		.dnone{
			display: none;
		}

		.w80mauto{
			width: 80%;
    		margin: auto;
		}

		.content-header{
			justify-content: space-around;
    		border-bottom: 2px solid #d1d1d1;
    		align-items: center;
		}

		.content-header > ul > li{
			display: inline-block;
			cursor: pointer;
		}

		.content-header > ul > li:hover > ul{
			height: auto;
			transition: .2s height;
		}

		.content-header ul.languages{
			position: absolute;
			height: 0;
			overflow: hidden;
		}

		.content-header ul.languages > li{
			padding: 12px 0;
		}

		.req-form > form{
			justify-content: space-around;
			flex-direction: column;
			width: 100%;
			margin: 25px auto;
		}

		.req-form > form > div{
			flex-direction: column;	
			text-align: center;
			margin-top: 10px;
			margin-bottom: 10px;
		}
		
		.req-form > form > div:last-child{
			justify-content: space-around;
			flex-direction: row;
		}

		.req-form > form > div:last-child > input{
			text-transform: uppercase;
		}

		.req-form > form label{
			text-transform: uppercase; 
		}

		.message-form > form{
			flex-direction: column;
			margin: auto;
			text-align: center;
		}

		.message-form > form textarea{
			max-width: 100%;
			min-height: 50px;
		}

		.error-block{
			border: 1px solid red;
		    padding: 5px 5px;
    		border-radius: 5px;
		}

		input{
			font-size: 20px;
    		border-radius: 5px;
    		padding: 0px 20px;
    		box-shadow: none;
		}

	</style>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
	<div class="dflex content-header w80mauto">
		<h2><?php echo $translate[$lang]["global_title"];?></h2>
		<ul>
			<li>
				<span><?php echo $translate[$lang]["language"];?></span>
				<ul class="languages">
					<li>
						EN
					</li>
					<li>
						RU
					</li>
				</ul>
			</li>
			<input type="hidden" name="current_url" value="<?php echo $current_path ;?>">
		</ul>
	</div>
	<div class="dflex req-form w80mauto">
		<form class="dflex" action="" method="POST">
			<div class="dflex w80mauto <?php echo ( isset($errors["from"]) ? "error-block" : "")?>">
				<label ><?php echo isset($errors["from"]) ? $errors["from"] : $translate[$lang]["from"];?></label>
				<input type="text" name="from" value="<?php echo $translate[$lang]["mine"];?>" disabled/>
				<input type="text" name="from" value="<?php echo $translate[$lang]["mine"];?>" class="dnone"/>
			</div>
			<div class="dflex w80mauto <?php echo ( isset($errors["wallet"]) ? "error-block" : "")?>">
				<label ><?php echo isset($errors["wallet"]) ? $errors["wallet"] : $translate[$lang]["wallet"];?></label>
				<input type="number" name="wallet" required/>
			</div>
			<div class="dflex w80mauto <?php echo ( isset($errors["price"]) ? "error-block" : "")?>">
				<label ><?php echo isset($errors["price"]) ? $errors["price"] : $translate[$lang]["price"];?></label>
				<input type="text" name="price" required/>
			</div>
			<div class="dflex w80mauto ">
				<input type="reset" value="<?php echo $translate[$lang]["reset"];?>">
				<input type="submit" name="pay" value="<?php echo $translate[$lang]["pay"];?>">
			</div>
		</form>
	</div>
	<?php if(isset($errors) && empty($errors)){?>
		<div>
			<?php 
				echo $res;
			?>
		</div>
	<?php } ?>

	<div class="dflex message-form w80mauto">
		<form class="dflex w80mauto" action="" method="POST">
			<h4><?php echo isset($error["message"]) ? $error["message"] : $translate[$lang]["message"];?></h4>
			<textarea name="message" required></textarea>
			<input type="submit" name="translate">
		</form>
	</div>
	<?php 
		if(isset($error) && empty($error["message"])){
			echo $message_result;
		}

	?>
	<script type="text/javascript">
		"use strict";
		jQuery(document).ready(function($){
			$(document).on( "click" , "div.content-header ul.languages li" , function (){
				let url = $("input[name='current_url']").val();
				$.ajax({
  					method: "POST",
  					url: url + "/lang.php",
  					data: { lang: $(this).html()}
				}).done(function (res){
					if( res ){
						location.reload();
					}
				});
			});
		})
	</script>
</body>
</html>
