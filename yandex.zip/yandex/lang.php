<?php 
	$res = 0;
	if(isset($_POST["lang"])){
		setcookie( "lang" , strtolower( trim( $_POST["lang"] ) ));
		$res = 1;
	}
	echo $res;
	die;;

?>